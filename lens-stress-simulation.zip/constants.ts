import type { Material, SimulationCase } from './types';

export const MATERIALS: Record<string, Material> = {
  SiNx: {
    name: 'Silicon Nitride (SiNx)',
    E: 320,
    nu: 0.23,
    alpha: 3.5,
    color: '#3b82f6', // blue-500
    category: 'inorganic',
    thickness: 0.05,
  },
  Acryl_Organic_Layer_1: {
    name: 'Organic Layer 1 (Acryl)',
    E: 2.5,
    nu: 0.40,
    alpha: 85,
    color: '#4b5563', // gray-600
    category: 'organic',
    thickness: 10,
  },
  Acryl_Organic_Layer_2: {
    name: 'Organic Layer 2 (Acryl)',
    E: 2.5,
    nu: 0.40,
    alpha: 85,
    color: '#9ca3af', // gray-400
    category: 'organic',
    thickness: 20,
  },
  High_k_Organic: {
    name: 'Black Organic Layer (high k)',
    E: 5,
    nu: 0.38,
    alpha: 55,
    color: '#1f2937', // gray-800
    category: 'organic',
    thickness: 2,
    width: 10,
  },
  High_n_Lens: {
    name: 'Lens (high n)',
    E: 100,
    nu: 0.25,
    alpha: 8,
    color: '#f97316', // orange-500
    category: 'inorganic',
    thickness: 11, // This is height
    width: 24,
  }
};

export const CASES_DATA: SimulationCase[] = [
  {
    id: 'CASE_1',
    title: 'Case 1: Baseline',
    description: 'The lens is in direct contact with Organic Layer 1. This configuration has the highest potential CTE mismatch at the interface.'
  },
  {
    id: 'CASE_2',
    title: 'Case 2: Stress Buffer Layer',
    description: 'A "Black Organic Layer" with intermediate CTE is added below the lens to act as a stress buffer between the lens and Organic Layer 1.'
  },
  {
    id: 'CASE_3',
    title: 'Case 3: Edge Protection',
    description: 'A thin SiNx layer is added to protect the edges of the interface, aiming to control stress concentration at the lens perimeter.'
  },
  {
    id: 'CASE_4',
    title: 'Case 4: Combined Solution',
    description: 'Combines the stress buffer layer (Case 2) and the edge protection layer (Case 3) for a potentially optimal design.'
  },
  {
    id: 'CASE_5',
    title: 'Case 5: Sub-Lens Protection',
    description: 'A full SiNx layer is placed under the lens to act as an adhesion promoter and mitigate stress at the primary interface.'
  },
  {
    id: 'CASE_6',
    title: 'Case 6: Sub-Lens & Buffer',
    description: 'Combines the stress buffer layer with a full sub-lens SiNx protection, aiming for maximum delamination resistance.'
  }
];
