import React, { useState, useEffect, useMemo } from 'react';
import { CASES_DATA, MATERIALS } from './constants';
import type { SimulationResult, Material } from './types';
import { calculateDelaminationRisk } from './services/stressSimulator';
import CaseCard from './components/CaseCard';
import ResultsChart from './components/ResultsChart';
import { Thermometer, Layers, AlertTriangle, CheckCircle2, Eye } from 'lucide-react';
import MaterialPropertiesTable from './components/MaterialPropertiesTable';

const getRainbowColorForScore = (score: number, maxScore: number) => {
  // Maps a score relative to the max score to a hue from 240 (blue) to 0 (red).
  const normalizedScore = maxScore > 0 ? (score / maxScore) * 100 : 0;
  const hue = 240 - (Math.min(100, Math.max(0, normalizedScore)) * 2.4);
  return `hsl(${hue}, 80%, 60%)`;
};

const App: React.FC = () => {
  const [simulationResults, setSimulationResults] = useState<SimulationResult[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [startTemp, setStartTemp] = useState<number>(25);
  const [endTemp, setEndTemp] = useState<number>(85);
  const [materials, setMaterials] = useState<Record<string, Material>>(MATERIALS);
  const [isStressViewEnabled, setIsStressViewEnabled] = useState<boolean>(false);

  const deltaT = useMemo(() => endTemp - startTemp, [startTemp, endTemp]);

  const runSimulation = () => {
    setIsLoading(true);
    setTimeout(() => {
      const results = calculateDelaminationRisk(materials, deltaT);
      setSimulationResults(results);
      setIsLoading(false);
    }, 1000); 
  };
  
  useEffect(() => {
    runSimulation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const maxStressValue = useMemo(() => {
    if (simulationResults.length === 0) return 100; // Default max
    return Math.max(...simulationResults.map(r => r.riskScore));
  }, [simulationResults]);


  const getRiskLevelInfo = (level: 'Low' | 'Medium' | 'High' | 'Very High', score: number) => {
    const color = getRainbowColorForScore(score, maxStressValue);
    switch (level) {
      case 'Low': return { icon: <CheckCircle2 className="h-5 w-5" />, color };
      case 'Medium': return { icon: <AlertTriangle className="h-5 w-5" />, color };
      case 'High': return { icon: <AlertTriangle className="h-5 w-5" />, color };
      case 'Very High': return { icon: <AlertTriangle className="h-5 w-5" />, color };
      default: return { icon: null, color: '#FFF' };
    }
  };

  const bestCase = useMemo(() => {
    if (simulationResults.length === 0) return null;
    return simulationResults.reduce((min, current) => current.riskScore < min.riskScore ? current : min);
  }, [simulationResults]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white tracking-tight">Multi-Layer Lens Thermo-Mechanical Stress Simulation</h1>
          <p className="mt-2 text-lg text-gray-400">Analyzing maximum stress from Coefficient of Thermal Expansion (CTE) mismatch.</p>
           <div className="mt-6">
            <button
                onClick={() => setIsStressViewEnabled(prev => !prev)}
                className={`px-6 py-2 rounded-full font-semibold transition-all duration-300 flex items-center justify-center mx-auto shadow-md ${
                    isStressViewEnabled
                    ? 'bg-red-600 text-white shadow-lg shadow-red-500/30 hover:bg-red-700'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
            >
                <Eye className="mr-2 h-5 w-5" />
                Stress View: {isStressViewEnabled ? 'ON' : 'OFF'}
            </button>
        </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 bg-gray-800/50 p-6 rounded-xl border border-gray-700">
            <h2 className="text-2xl font-semibold text-white mb-4">Simulation Parameters</h2>
            
            <div className="space-y-6">
              <div>
                <label className="flex items-center text-lg font-medium mb-2">
                  <Thermometer className="mr-2 h-5 w-5 text-cyan-400"/> Temperature Change (ΔT)
                </label>
                <div className="flex items-center space-x-4">
                    <span className="text-sm">Start: {startTemp}°C</span>
                     <input type="range" min="0" max="150" value={startTemp} onChange={e => setStartTemp(Number(e.target.value))} className="w-full" />
                </div>
                 <div className="flex items-center space-x-4 mt-2">
                    <span className="text-sm">End: {endTemp}°C</span>
                     <input type="range" min="0" max="150" value={endTemp} onChange={e => setEndTemp(Number(e.target.value))} className="w-full" />
                </div>
                <div className="mt-2 text-center text-xl font-bold text-cyan-300">{deltaT}°C</div>
              </div>

              <div>
                <h3 className="flex items-center text-lg font-medium mb-2">
                  <Layers className="mr-2 h-5 w-5 text-purple-400"/> Material & Geometry Properties
                </h3>
                <MaterialPropertiesTable materials={materials} setMaterials={setMaterials} />
              </div>
              
              <button 
                onClick={runSimulation}
                disabled={isLoading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 disabled:bg-gray-500 flex items-center justify-center"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Simulating...
                  </>
                ) : 'Run Simulation'}
              </button>
            </div>
          </div>
          
          <main className="lg:col-span-2 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {CASES_DATA.map((caseInfo) => {
                const result = simulationResults.find(r => r.caseId === caseInfo.id);
                const riskInfo = result ? getRiskLevelInfo(result.riskLevel, result.riskScore) : null;
                return (
                  <CaseCard 
                    key={caseInfo.id}
                    caseData={caseInfo}
                    result={result}
                    isLoading={isLoading}
                    riskInfo={riskInfo}
                    isBest={bestCase?.caseId === caseInfo.id}
                    isStressViewEnabled={isStressViewEnabled}
                    materials={materials}
                  />
                );
              })}
            </div>

            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700">
                <h2 className="text-2xl font-semibold text-white mb-4">Results Comparison</h2>
                <div className="h-80">
                  <ResultsChart results={simulationResults} />
                </div>
            </div>

             {bestCase && !isLoading && (
              <div className="bg-green-900/50 border border-green-700 p-6 rounded-xl flex items-center space-x-4">
                <CheckCircle2 className="h-10 w-10 text-green-400 flex-shrink-0" />
                <div>
                  <h3 className="text-xl font-semibold text-white">Optimal Design</h3>
                  <p className="text-green-300">
                    Based on the simulation, <span className="font-bold">{CASES_DATA.find(c => c.id === bestCase.caseId)?.title}</span> demonstrates the lowest maximum stress of <span className="font-bold">{bestCase.riskScore.toFixed(2)} MPa</span>. This design is recommended for better thermo-mechanical stability.
                  </p>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default App;
