// Fix: Define and export all necessary types for the application.
// The previous file had constants and a circular import, which was incorrect.
export type CaseId =
  | 'CASE_1'
  | 'CASE_2'
  | 'CASE_3'
  | 'CASE_4'
  | 'CASE_5'
  | 'CASE_6';

export interface Material {
  name: string;
  E: number; // Young's Modulus in GPa
  nu: number; // Poisson's Ratio
  alpha: number; // Coefficient of Thermal Expansion in ppm/K
  color: string;
  category: 'inorganic' | 'organic';
  thickness: number; // in µm
  width?: number; // in µm
}

export interface SimulationCase {
  id: CaseId;
  title: string;
  description: string;
}

export interface SimulationResult {
  caseId: CaseId;
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Very High';
}
