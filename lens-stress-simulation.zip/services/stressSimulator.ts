import type { Material, SimulationResult, CaseId } from '../types';

// Geometric factors for stress concentration at sharp corners.
const STRESS_CONCENTRATION_FACTOR = 1.3; // Stress is 30% higher at an unprotected lens edge.
const EDGE_MITIGATION_FACTOR = 0.8; // SiNx edge protection reduces corner stress by 20%.

const getStressLevel = (stress: number): 'Low' | 'Medium' | 'High' | 'Very High' => {
  if (stress < 50) return 'Low';
  if (stress < 100) return 'Medium';
  if (stress < 150) return 'High';
  return 'Very High';
};

export const calculateDelaminationRisk = (materials: Record<string, Material>, deltaT: number): SimulationResult[] => {
  // Biaxial Modulus M = E / (1 - nu)
  const getBiaxialModulus = (mat: Material): number => mat.E / (1 - mat.nu);

  // Calculates the stress in mat1 at the interface with mat2 using a bilayer model.
  // The model incorporates material properties (E, nu, alpha) and thickness (t).
  const calculateInterfaceStress = (mat1: Material, mat2: Material): number => {
    // Ensure thickness values are valid for this model.
    if (!mat1.thickness || !mat2.thickness || mat1.thickness <= 0 || mat2.thickness <= 0) {
      // Fallback for layers without defined thickness (e.g., if user deletes it)
      const strain = Math.abs(mat1.alpha - mat2.alpha) * deltaT * 1e-6; // ppm/K -> strain
      return strain * getBiaxialModulus(mat1);
    }
    
    const m1 = getBiaxialModulus(mat1);
    const m2 = getBiaxialModulus(mat2);
    const t1 = mat1.thickness;
    const t2 = mat2.thickness;

    // CTE mismatch strain, converting ppm/K to absolute
    const strain = (mat2.alpha - mat1.alpha) * deltaT * 1e-6;

    // Stress in layer 1 due to mismatch with layer 2
    const stress1 = strain * m1 * (m2 * t2) / (m1 * t1 + m2 * t2);
    
    return Math.abs(stress1); // Return absolute stress value in GPa
  };

  const { High_n_Lens, Acryl_Organic_Layer_1, Acryl_Organic_Layer_2, High_k_Organic, SiNx } = materials;

  // --- Case-by-case stress analysis ---
  // The logic follows the case DESCRIPTIONS to differentiate them,
  // especially for C3/C4 (edge effects) vs C5/C6 (no edge effects).

  // Global stress component: The top of the lens is always surrounded by Organic Layer 2.
  // Its thickness and high CTE are a major contributor to stress on the lens.
  const globalStressOnLens = calculateInterfaceStress(High_n_Lens, Acryl_Organic_Layer_2);

  // Case 1 (Baseline): Unprotected Lens/Org1 corner.
  const local_c1 = calculateInterfaceStress(High_n_Lens, Acryl_Organic_Layer_1) * STRESS_CONCENTRATION_FACTOR;
  const maxStress_c1 = Math.max(local_c1, globalStressOnLens);

  // Case 2 (Buffer): Unprotected Lens/Buffer corner.
  const local_c2_interface1 = calculateInterfaceStress(High_n_Lens, High_k_Organic) * STRESS_CONCENTRATION_FACTOR;
  const local_c2_interface2 = calculateInterfaceStress(High_k_Organic, Acryl_Organic_Layer_1);
  const maxStress_c2 = Math.max(local_c2_interface1, local_c2_interface2, globalStressOnLens);

  // Case 3 (Edge Protection): Lens/Org1 corner is mitigated by SiNx.
  const local_c3 = calculateInterfaceStress(High_n_Lens, Acryl_Organic_Layer_1) * STRESS_CONCENTRATION_FACTOR * EDGE_MITIGATION_FACTOR;
  const maxStress_c3 = Math.max(local_c3, globalStressOnLens);

  // Case 4 (Combined): Lens/Buffer corner is mitigated by SiNx.
  const local_c4_interface1 = calculateInterfaceStress(High_n_Lens, High_k_Organic) * STRESS_CONCENTRATION_FACTOR * EDGE_MITIGATION_FACTOR;
  const local_c4_interface2 = calculateInterfaceStress(High_k_Organic, Acryl_Organic_Layer_1);
  const maxStress_c4 = Math.max(local_c4_interface1, local_c4_interface2, globalStressOnLens);

  // Case 5 (Sub-Lens): No corner concentration at the lens bottom. Interfaces are flat.
  const local_c5_interface1 = calculateInterfaceStress(High_n_Lens, SiNx);
  const local_c5_interface2 = calculateInterfaceStress(SiNx, Acryl_Organic_Layer_1);
  const maxStress_c5 = Math.max(local_c5_interface1, local_c5_interface2, globalStressOnLens);

  // Case 6 (Sub-Lens + Buffer): No corner concentration. Interfaces are flat. Structure from diagram.
  const local_c6_interface1 = calculateInterfaceStress(High_n_Lens, SiNx); // Lens bottom on SiNx
  const local_c6_interface2 = calculateInterfaceStress(SiNx, High_k_Organic); // SiNx on Buffer
  const local_c6_interface3 = calculateInterfaceStress(High_k_Organic, Acryl_Organic_Layer_1); // Buffer on Org1
  const maxStress_c6 = Math.max(local_c6_interface1, local_c6_interface2, local_c6_interface3, globalStressOnLens);

  const resultsInGpa = [
    { caseId: 'CASE_1', stress: maxStress_c1 },
    { caseId: 'CASE_2', stress: maxStress_c2 },
    { caseId: 'CASE_3', stress: maxStress_c3 },
    { caseId: 'CASE_4', stress: maxStress_c4 },
    { caseId: 'CASE_5', stress: maxStress_c5 },
    { caseId: 'CASE_6', stress: maxStress_c6 },
  ];

  return resultsInGpa.map(({ caseId, stress }) => {
    const stressInMpa = stress * 1000; // Convert GPa to MPa
    return {
      caseId: caseId as CaseId,
      riskScore: isNaN(stressInMpa) ? 0 : stressInMpa, // Keep field name for type safety
      riskLevel: getStressLevel(stressInMpa),
    };
  });
};
