import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import type { SimulationResult } from '../types';

interface ResultsChartProps {
  results: SimulationResult[];
}

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-700 p-2 border border-gray-600 rounded">
        <p className="label text-white">{`Case ${label.split(' ')[1]}`}</p>
        <p className="intro" style={{ color: payload[0].payload.color }}>{`Max Stress : ${payload[0].value.toFixed(2)} MPa`}</p>
      </div>
    );
  }
  return null;
};

const getRainbowColorForScore = (score: number, maxScore: number) => {
  // Maps a score relative to the max score to a hue from 240 (blue) to 0 (red).
  const normalizedScore = maxScore > 0 ? (score / maxScore) * 100 : 0;
  const hue = 240 - (Math.min(100, Math.max(0, normalizedScore)) * 2.4);
  return `hsl(${hue}, 80%, 60%)`;
};


const ResultsChart: React.FC<ResultsChartProps> = ({ results }) => {
    
  const maxStress = React.useMemo(() => {
    if (results.length === 0) return 1;
    return Math.max(...results.map(r => r.riskScore), 1);
  }, [results]);

  const chartData = results.map(r => ({
    name: `Case ${r.caseId.split('_')[1]}`,
    stressValue: r.riskScore,
    color: getRainbowColorForScore(r.riskScore, maxStress),
  }));

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={chartData}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#4a5568" />
        <XAxis dataKey="name" stroke="#d1d5db" />
        <YAxis 
            stroke="#d1d5db" 
            label={{ value: 'Max Stress (MPa)', angle: -90, position: 'insideLeft', fill: '#d1d5db' }} 
            domain={[0, (dataMax: number) => Math.ceil(dataMax * 1.1)]}
        />
        <Tooltip content={<CustomTooltip />} cursor={{fill: 'rgba(107, 114, 128, 0.2)'}} />
        <Legend wrapperStyle={{ color: '#d1d5db' }}/>
        <Bar dataKey="stressValue" name="Max Stress (MPa)">
            {
                chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                ))
            }
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default ResultsChart;
