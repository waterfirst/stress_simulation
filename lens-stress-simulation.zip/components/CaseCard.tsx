import React from 'react';
import type { SimulationCase, SimulationResult, Material } from '../types';
import CaseDiagram from './CaseDiagram';

interface CaseCardProps {
  caseData: SimulationCase;
  result: SimulationResult | undefined;
  isLoading: boolean;
  riskInfo: { icon: React.ReactElement; color: string } | null;
  isBest: boolean;
  isStressViewEnabled: boolean;
  materials: Record<string, Material>;
}

const CaseCard: React.FC<CaseCardProps> = ({ caseData, result, isLoading, riskInfo, isBest, isStressViewEnabled, materials }) => {
  return (
    <div className={`bg-gray-800/50 rounded-xl border ${isBest && !isLoading ? 'border-green-500/50 bg-green-900/20' : 'border-gray-700'} p-4 transition-all duration-300`}>
      <h3 className="text-lg font-semibold text-white mb-2">{caseData.title}</h3>
      <div className="w-full h-40 bg-gray-900/50 rounded-md flex items-center justify-center p-2 mb-3 overflow-hidden">
        <CaseDiagram 
          caseId={caseData.id} 
          isStressViewEnabled={isStressViewEnabled}
          riskScore={result?.riskScore}
          materials={materials}
        />
      </div>
      <p className="text-sm text-gray-400 mb-4 min-h-[60px]">{caseData.description}</p>
      
      <div className="bg-gray-900/50 p-3 rounded-lg min-h-[76px]">
        {isLoading ? (
          <div className="animate-pulse flex space-x-4">
            <div className="flex-1 space-y-3 py-1">
              <div className="h-2 bg-gray-700 rounded"></div>
              <div className="h-2 bg-gray-700 rounded w-3/4"></div>
            </div>
          </div>
        ) : result && riskInfo ? (
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm font-medium text-gray-300">Max Stress (MPa)</span>
              <span 
                className="text-xl font-bold"
                style={{ color: riskInfo.color }}
              >
                {result.riskScore.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-300">Stress Level</span>
              <div 
                className="flex items-center space-x-1 font-semibold"
                style={{ color: riskInfo.color }}
              >
                {riskInfo.icon}
                <span>{result.riskLevel}</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-500">No data</div>
        )}
      </div>
    </div>
  );
};

export default CaseCard;
