import React from 'react';
import type { CaseId, Material } from '../types';

interface CaseDiagramProps {
  caseId: CaseId;
  isStressViewEnabled?: boolean;
  riskScore?: number;
  materials: Record<string, Material>;
}

const StressPoint: React.FC<{ cx: number; cy: number; riskScore: number }> = ({ cx, cy, riskScore }) => {
  if (riskScore <= 0) return null;

  const maxRadius = 30;
  const scoreFraction = riskScore / 100;
  const uniqueId = `grad-${cx}-${cy}`.replace('.', '');

  return (
    <g style={{ filter: 'blur(2px)', transformOrigin: `${cx}px ${cy}px`, transform: `scale(${scoreFraction})` }}>
      <defs>
        <radialGradient id={`${uniqueId}-red`}>
          <stop offset="0%" stopColor="#ef4444" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${uniqueId}-yellow`}>
          <stop offset="0%" stopColor="#facc15" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#facc15" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${uniqueId}-cyan`}>
          <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#22d3ee" stopOpacity="0" />
        </radialGradient>
      </defs>
      
      <circle cx={cx} cy={cy} r={maxRadius} fill={`url(#${uniqueId}-cyan)`} />
      <circle cx={cx} cy={cy} r={maxRadius * 0.75} fill={`url(#${uniqueId}-yellow)`} />
      <circle cx={cx} cy={cy} r={maxRadius * 0.5} fill={`url(#${uniqueId}-red)`} />
    </g>
  );
};


const CaseDiagram: React.FC<CaseDiagramProps> = ({ caseId, isStressViewEnabled, riskScore, materials }) => {
  const { 
    High_n_Lens, 
    Acryl_Organic_Layer_1, 
    Acryl_Organic_Layer_2, 
    High_k_Organic, 
    SiNx 
  } = materials;

  // Dimensions are scaled for SVG viewbox
  const scale = 5;
  const lensWidth = (High_n_Lens.width || 0) * scale;
  const lensHeight = (High_n_Lens.thickness || 0) * scale;
  const org1Height = (Acryl_Organic_Layer_1.thickness || 0) * scale;
  const org2Height = (Acryl_Organic_Layer_2.thickness || 0) * scale;
  const blackLayerHeight = (High_k_Organic.thickness || 0) * scale;
  const blackLayerWidth = (High_k_Organic.width || 0) * scale;
  const sinxHeight = (SiNx.thickness || 0) * scale; 

  const totalWidth = lensWidth + 2 * blackLayerWidth;
  const totalHeight = org1Height + org2Height + lensHeight;

  const viewBox = `0 0 ${totalWidth} ${totalHeight}`;
  const midX = totalWidth / 2;
  const org1Y = totalHeight - org1Height;
  const org2Y = org1Y - lensHeight;

  // Common elements
  const OrgLayer1 = <rect x="0" y={org1Y} width={totalWidth} height={org1Height} fill={Acryl_Organic_Layer_1.color} />;
  const Lens = ({ yPos }: { yPos: number }) => (
    <path 
      d={`M ${midX - lensWidth / 2},${yPos} a ${lensWidth/2},${lensHeight} 0 0,1 ${lensWidth},0 Z`}
      fill={High_n_Lens.color}
    />
  );
  const OrgLayer2 = <rect x="0" y="0" width={totalWidth} height={org2Y + lensHeight} fill={Acryl_Organic_Layer_2.color} />;
  
  const BlackLayer = (
    <>
      <rect x={midX - lensWidth / 2 - blackLayerWidth} y={org1Y - blackLayerHeight} width={blackLayerWidth} height={blackLayerHeight} fill={High_k_Organic.color} />
      <rect x={midX + lensWidth / 2} y={org1Y - blackLayerHeight} width={blackLayerWidth} height={blackLayerHeight} fill={High_k_Organic.color} />
    </>
  );
  
  const SiNxLayer = ({ yPos, width, xPos }: { yPos: number; width: number; xPos: number; }) => (
     <rect x={xPos} y={yPos} width={width} height={sinxHeight} fill={SiNx.color} />
  );
  
  const SiNxLayerCase4 = (
    <>
      <SiNxLayer yPos={org1Y - blackLayerHeight - sinxHeight} width={blackLayerWidth} xPos={midX - lensWidth / 2 - blackLayerWidth} />
      <SiNxLayer yPos={org1Y - blackLayerHeight - sinxHeight} width={blackLayerWidth} xPos={midX + lensWidth / 2} />
    </>
  );

  const renderCase = () => {
    switch (caseId) {
      case 'CASE_1':
        return (
          <>
            {OrgLayer2}
            {OrgLayer1}
            <Lens yPos={org1Y} />
          </>
        );
      case 'CASE_2':
        return (
          <>
            {OrgLayer2}
            {OrgLayer1}
            {BlackLayer}
            <Lens yPos={org1Y} />
          </>
        );
      case 'CASE_3':
         return (
          <>
            {OrgLayer2}
            {OrgLayer1}
            <SiNxLayer yPos={org1Y - sinxHeight} width={totalWidth} xPos={0}/>
            <Lens yPos={org1Y} />
          </>
        );
      case 'CASE_4':
         return (
          <>
            {OrgLayer2}
            {OrgLayer1}
            {BlackLayer}
            {SiNxLayerCase4}
            <Lens yPos={org1Y} />
          </>
        );
      case 'CASE_5':
        return (
          <>
            {OrgLayer2}
            {OrgLayer1}
            <SiNxLayer yPos={org1Y - sinxHeight} width={totalWidth} xPos={0}/>
            <Lens yPos={org1Y - sinxHeight} />
          </>
        );
      case 'CASE_6': {
        // Define coordinates for clarity
        const leftBM_x1 = midX - lensWidth / 2 - blackLayerWidth;
        const leftBM_x2 = midX - lensWidth / 2;
        const rightBM_x1 = midX + lensWidth / 2;
        const rightBM_x2 = midX + lensWidth / 2 + blackLayerWidth;

        const bm_top_y = org1Y - blackLayerHeight;
        const org1_top_y = org1Y;

        const sinx_top_y_over_bm = bm_top_y - sinxHeight;
        const sinx_top_y_in_trench = org1_top_y - sinxHeight;

        // Path for the conformal SiNx layer that covers the black layers and the organic layer between them
        const siNxPath = `
          M ${leftBM_x1},${sinx_top_y_over_bm}
          L ${leftBM_x2},${sinx_top_y_over_bm}
          L ${leftBM_x2},${sinx_top_y_in_trench}
          L ${rightBM_x1},${sinx_top_y_in_trench}
          L ${rightBM_x1},${sinx_top_y_over_bm}
          L ${rightBM_x2},${sinx_top_y_over_bm}
          L ${rightBM_x2},${bm_top_y}
          L ${rightBM_x1},${bm_top_y}
          L ${rightBM_x1},${org1_top_y}
          L ${leftBM_x2},${org1_top_y}
          L ${leftBM_x2},${bm_top_y}
          L ${leftBM_x1},${bm_top_y}
          Z`;
        
        return (
          <>
            {OrgLayer2}
            {OrgLayer1}
            {BlackLayer}
            <path d={siNxPath} fill={SiNx.color} stroke={SiNx.color} strokeWidth="0.5" />
            <Lens yPos={sinx_top_y_in_trench} />
          </>
        );
      }
      default:
        return null;
    }
  };

  const stressPointLeftX = midX - lensWidth / 2;
  const stressPointRightX = midX + lensWidth / 2;
  const stressPointY = (() => {
    switch (caseId) {
        case 'CASE_5': return org1Y - sinxHeight;
        case 'CASE_6': return org1Y - sinxHeight;
        default: return org1Y;
    }
  })();

  return (
    <svg viewBox={viewBox} width="100%" height="100%" preserveAspectRatio="xMidYMid meet">
      {renderCase()}
      {isStressViewEnabled && riskScore !== undefined && (
        <>
            <StressPoint cx={stressPointLeftX} cy={stressPointY} riskScore={riskScore} />
            <StressPoint cx={stressPointRightX} cy={stressPointY} riskScore={riskScore} />
        </>
      )}
    </svg>
  );
};

export default CaseDiagram;