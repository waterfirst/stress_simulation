import React from 'react';
import type { Material } from '../types';

interface MaterialPropertiesTableProps {
    materials: Record<string, Material>;
    setMaterials: React.Dispatch<React.SetStateAction<Record<string, Material>>>;
}

const MaterialPropertiesTable: React.FC<MaterialPropertiesTableProps> = ({ materials, setMaterials }) => {

    const handleMaterialChange = (materialKey: string, field: keyof Material, value: any) => {
        const numericValue = parseFloat(value);
        if (isNaN(numericValue) && value !== "") return;
        
        setMaterials(prev => ({
            ...prev,
            [materialKey]: {
                ...prev[materialKey],
                [field]: isNaN(numericValue) ? undefined : numericValue
            }
        }));
    };

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-400">
                <thead className="text-xs text-gray-300 uppercase bg-gray-700/50">
                    <tr>
                        <th scope="col" className="px-2 py-2">Material</th>
                        <th scope="col" className="px-2 py-2 text-center">E (GPa)</th>
                        <th scope="col" className="px-2 py-2 text-center">CTE (ppm/K)</th>
                        <th scope="col" className="px-2 py-2 text-center">Thick (µm)</th>
                        <th scope="col" className="px-2 py-2 text-center">Width (µm)</th>
                    </tr>
                </thead>
                <tbody>
                    {Object.keys(materials).map((key) => {
                        const material = materials[key];
                        const inputClass = "w-16 bg-gray-800 text-center rounded border border-gray-600 focus:ring-indigo-500 focus:border-indigo-500";
                        return (
                            <tr key={key} className="border-b border-gray-700 hover:bg-gray-700/30">
                                <td className="px-2 py-2 font-medium text-gray-200 whitespace-nowrap flex items-center">
                                    <span className="w-3 h-3 rounded-full mr-2 flex-shrink-0" style={{ backgroundColor: material.color }}></span>
                                    <span className="text-xs">{material.name}</span>
                                </td>
                                <td className="px-2 py-2">
                                    <input 
                                        type="number" 
                                        value={material.E} 
                                        onChange={(e) => handleMaterialChange(key, 'E', e.target.value)}
                                        className={inputClass}
                                    />
                                </td>
                                <td className="px-2 py-2">
                                    <input 
                                        type="number" 
                                        value={material.alpha} 
                                        onChange={(e) => handleMaterialChange(key, 'alpha', e.target.value)}
                                        className={inputClass}
                                    />
                                </td>
                                <td className="px-2 py-2">
                                    {material.thickness !== undefined && (
                                        <input 
                                            type="number" 
                                            value={material.thickness} 
                                            onChange={(e) => handleMaterialChange(key, 'thickness', e.target.value)}
                                            className={inputClass}
                                        />
                                    )}
                                </td>
                                <td className="px-2 py-2">
                                    {material.width !== undefined && (
                                        <input 
                                            type="number" 
                                            value={material.width} 
                                            onChange={(e) => handleMaterialChange(key, 'width', e.target.value)}
                                            className={inputClass}
                                        />
                                    )}
                                </td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
        </div>
    );
};

export default MaterialPropertiesTable;
